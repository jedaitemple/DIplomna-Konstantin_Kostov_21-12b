package kosio.myapplication;
import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import  kosio.myapplication.custom.CustomActivity;
import  kosio.myapplication.Utilities.Const;
import com.parse.FindCallback;
import com.parse.ParseException;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.parse.ParseUser;


public class Users extends CustomActivity
{	private static int RESULT_LOAD_IMAGE = 1;
	private ArrayList<ParseUser> uList;
	/** The user. */
	public static ParseUser user;

	/* (non-Javadoc)
	 * @see android.support.v4.app.FragmentActivity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_list);

		getActionBar().setDisplayHomeAsUpEnabled(true);






	}
	public boolean onOptionsItemSelected(MenuItem item)
	{
		if (item.getItemId() == android.R.id.home)
		{
			finish();

		}

		return super.onOptionsItemSelected(item);
	}



	/* (non-Javadoc)
	 * @see android.support.v4.app.FragmentActivity#onResume()
	 */
	@Override
	protected void onResume()
	{
		super.onResume();
		loadUserList();

	}


	private void loadUserList()
	{

		ParseUser.getQuery().whereNotEqualTo("username", user.getUsername())
				.findInBackground(new FindCallback<ParseUser>() {

					@Override
					public void done(List<ParseUser> li, ParseException e) {
						if (li != null) {
							uList = new ArrayList<ParseUser>(li);
							ListView list = (ListView) findViewById(R.id.list);
							list.setAdapter(new UserAdapter());
							list.setOnItemClickListener(new OnItemClickListener() {

								@Override
								public void onItemClick(AdapterView<?> arg0,
														View arg1, int pos, long arg3) {
									startActivity(new Intent(Users.this,
											Chat.class).putExtra(
											Const.EXTRA_DATA, uList.get(pos)
													.getUsername()));
								}
							});
						}}
				});
	}
	/**
	 * The Class UserAdapter is the adapter class for User ListView. This
	 * adapter shows the user name and it's only online status for each item.
	 */
	private class UserAdapter extends BaseAdapter
	{

		@Override
		public int getCount()

		{
			return uList.size();
		}
		public ParseUser getItem(int arg0)
		{

			return uList.get(arg0);
		}
		public long getItemId(int arg0)
		{
			return arg0;
		}

		@Override
		public View getView(int pos, View v, ViewGroup arg2)
		{
			if (v == null)
				v = getLayoutInflater().inflate(R.layout.chat_item, null);

			ParseUser c = getItem(pos);
			TextView lbl = (TextView) v;
			lbl.setText(c.getUsername());
			lbl.setCompoundDrawablesWithIntrinsicBounds(
					 R.drawable.users, 0, R.drawable.arrow, 0);
			return v;
		}

	}
}
