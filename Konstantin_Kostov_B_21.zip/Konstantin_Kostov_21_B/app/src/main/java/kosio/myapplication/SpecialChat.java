package kosio.myapplication;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.os.Handler;
import android.text.InputType;
import android.text.format.DateUtils;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.parse.ParseObject;
import android.graphics.Bitmap;
import android.view.View.OnClickListener;
import android.widget.Button;

import  kosio.myapplication.custom.CustomActivity;
import  kosio.myapplication.Conv.Conversation;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.SaveCallback;
import android.widget.ImageView;

import java.io.FileDescriptor;
import java.io.IOException;

import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

/**
 * Created by Kosioplay on 30.1.2016 г..
 */

import android.os.SystemClock;

public class SpecialChat extends CustomActivity {

    /**
     * The Conversation list.
     */
    private ArrayList<Conversation> convList;

    /**
     * The chat adapter.
     */

    /**
     * The Editext to compose the message.
     */


    private EditText txt;
    private String receiver;

    EditText eText;
    Button btn;
    // GUI components

    protected void onCreate(Bundle savedInstanceState) {  // Image loading result to pass to startActivityForResult method.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.specialchat);
        deleteStudent();
        convList = new ArrayList<Conversation>();
        ListView list = (ListView) findViewById(R.id.list);
        list.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        list.setStackFromBottom(true);

        txt = (EditText) findViewById(R.id.txt);
        txt.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        eText = (EditText) findViewById(R.id.edittext);
        btn = (Button) findViewById(R.id.btnuser);
        btn.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                String str = eText.getText().toString();
                receiver = str;
                Toast msg = Toast.makeText(getBaseContext(), str, Toast.LENGTH_LONG);
                msg.show();
            }
        });

        setTouchNClick(R.id.btnSend);

    }

    /* (non-Javadoc)
     * @see android.support.v4.app.FragmentActivity#onResume()
     */

    public void deleteStudent(){
        ParseQuery<ParseObject> query=ParseQuery.getQuery("Chat");
        query.whereEqualTo("special", "special");
        query.whereEqualTo("receiver", Users.user.getUsername());
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> parseObjects, ParseException e) {
                if (e == null) {


                    for (ParseObject delete : parseObjects) {
                        delete.deleteInBackground();
                        Toast.makeText(getApplicationContext(), "deleted", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "error in deleting", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private Bitmap getBitmapFromUri(Uri uri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptor =
                getContentResolver().openFileDescriptor(uri, "r");
        FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
        Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);
        parcelFileDescriptor.close();
        return image;
    }


    public void onClick(View v)
    {
        super.onClick(v);
        if (v.getId() == R.id.btnSend)
        {
            sendMessage();
        }

    }





    private void sendMessage()
    {
        if (txt.length() == 0)
            return;

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(txt.getWindowToken(), 0);

        String s = txt.getText().toString();
        final Conversation c = new Conversation(s, new Date(),
                Users.user.getUsername());
        convList.add(c);
        txt.setText(null);

        ParseObject po = new ParseObject("Chat");
        po.put("sender", Users.user.getUsername());
        po.put("receiver", receiver);
        // po.put("createdAt", "");
        po.put("special", "special");
        s= "Special MESSAGE WILL BE DELETE" +s;
        po.put("message", s);

        po.saveEventually(new SaveCallback() {

            @Override
            public void done(ParseException e) {
                if (e == null) {
                    Toast.makeText(getApplicationContext(), "the message was sended succsessfully",

                            Toast.LENGTH_SHORT).show();
                } else {

                }
            }
        });
    }






    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == android.R.id.home)
        {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}












