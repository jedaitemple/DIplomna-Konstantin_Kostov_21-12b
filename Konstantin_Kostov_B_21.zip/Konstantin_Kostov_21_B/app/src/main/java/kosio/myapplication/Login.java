package kosio.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.parse.ParseUser;
import  kosio.myapplication.custom.CustomActivity;

import com.parse.LogInCallback;
import com.parse.ParseException;

import android.widget.Toast;

/**
 * The Class Login is an Activity class that shows the login screen to users.
 * The current implementation simply includes the options for Login and button
 * for Register. On login button click, it sends the Login details to Parse
 * server to verify user.
 */
public class Login extends CustomActivity
{
	Button loginbutton;

	private EditText username1;
	private EditText password1;

	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		ParseUser currentUser = ParseUser.getCurrentUser();

		if (currentUser == null) {
			// It's an anonymous user, hence show the login screen
		}
		else {
			// The user is logged in, yay!!

		}
		username1 = (EditText) findViewById(R.id.user);
		password1 = (EditText) findViewById(R.id.pwd);


		final Button  loginbutton = (Button)findViewById(R.id.btnLogin);
		loginbutton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {
				String username = username1.getText().toString();
				String password = password1.getText().toString();
				if (username.length() == 0 || password.length() == 0)
				{
					Toast.makeText(getApplicationContext(), "Plese fill password and username", Toast.LENGTH_SHORT).show();
					return;
				}
				ParseUser.logInInBackground(username, password, new LogInCallback() {

					@Override
					public void done(ParseUser user, ParseException e)
					{
						if (user != null)
						{
							Users.user = user;
							startActivity(new Intent(Login.this, Main2Activity.class));
							finish();
						}
						else
						{
							Toast.makeText(getApplicationContext(), "No such user or password", Toast.LENGTH_SHORT).show();
						}
					}
				});

			}
		});
		final Button switchact =(Button)findViewById(R.id.btnReg);
		switchact.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {

				Intent intent = new Intent(Login.this, Register.class);
				startActivity(intent);

			}
		});




	}
}
