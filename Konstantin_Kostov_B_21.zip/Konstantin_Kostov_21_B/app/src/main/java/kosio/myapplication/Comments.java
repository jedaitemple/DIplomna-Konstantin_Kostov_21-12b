package kosio.myapplication;

import android.content.Intent;
import android.view.MotionEvent;
import android.widget.Toast;
import android.os.Bundle;
import android.support.v4.view.GestureDetectorCompat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import android.content.Context;
import android.os.Handler;
import android.text.InputType;
import android.text.format.DateUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.parse.ParseObject;
import android.graphics.Bitmap;
import android.widget.Button;

import  kosio.myapplication.custom.CustomActivity;
import  kosio.myapplication.Conv.Conversation;
import  kosio.myapplication.Utilities.Const;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.SaveCallback;

import android.widget.ImageView;

/**
 * The Class Chat is the Activity class that holds main chat screen. It shows
 * all the conversation messages between two users and also allows the user to
 * send and receive messages.
 */
public class Comments extends CustomActivity {
    Bitmap bmp = null;
    private ArrayList<Conversation> convList;


    private ChatAdapter adp;

    private EditText txt;

    private String buddy;

    private Date lastMsgDate;

    private boolean isRunning;


    private static Handler handler;
    private static int RESULT_LOAD_IMAGE = 1;
    Button button;
    ImageView viewImage;
    Button b;
    String a;
    private Blog blog;
    private EditText titleEditText;
    private EditText idEditText;
    private EditText contentEditText;
    /* (non-Javadoc)
     * @see android.support.v4.app.FragmentActivity#onCreate(android.os.Bundle)
     */
    private GestureDetectorCompat gestureDetectorCompat;
    // GUI components


    protected void onCreate(Bundle savedInstanceState) {  // Image loading result to pass to startActivityForResult method.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comments);
        Intent intent = this.getIntent();

        if (intent.getExtras() != null) {
            blog = new Blog(intent.getStringExtra("noteId"), intent.getStringExtra("noteTitle"), intent.getStringExtra("noteContent"));
        }

        convList = new ArrayList<Conversation>();
        ListView list = (ListView) findViewById(R.id.list);
        adp = new ChatAdapter();
        list.setAdapter(adp);
        list.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        list.setStackFromBottom(true);

        txt = (EditText) findViewById(R.id.txt);
        setTouchNClick(R.id.btnSend);

    }
    public boolean onTouchEvent(MotionEvent event) {
        this.gestureDetectorCompat.onTouchEvent(event);
        return super.onTouchEvent(event);
    }




    public void onClick(View v)
    {
        super.onClick(v);
        if (v.getId() == R.id.btnSend)
        {
            sendMessage();
        }

    }



    /**
     * send comment
     */
    private void sendMessage() {
        if (txt.length() == 0)
            return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(txt.getWindowToken(), 0);

        String s = txt.getText().toString();
        final Conversation c = new Conversation(s, new Date(),
                Users.user.getUsername());

        c.setStatus(Conversation.STATUS_SENDING);
        convList.add(c);
        adp.notifyDataSetChanged();
        txt.setText(null);


        ParseObject po = new ParseObject("Comments");
        po.put("sender", Users.user.getUsername());
        po.put("receiver", blog.getId());
        // po.put("createdAt", "");
        s=Users.user.getUsername() +"        "  +  s;
        po.put("message", s);
        po.saveEventually(new SaveCallback() {

            @Override
            public void done(ParseException e) {
                if (e == null)
                    c.setStatus(Conversation.STATUS_SENT);
                else
                    c.setStatus(Conversation.STATUS_FAILED);
                adp.notifyDataSetChanged();
            }
        });
    }

    private void loadConversationList()
    {
        ParseQuery<ParseObject> q = ParseQuery.getQuery("Comments");
        if (convList.size() == 0)
        {
            // load all messages...
            ArrayList<String> al = new ArrayList<String>();
            al.add(buddy);
            al.add(Users.user.getUsername());


            q.whereContainedIn("sender", al);
            q.whereContainedIn("receiver",al);
        }
        else
        {
            // load only newly received message..
            if (lastMsgDate != null)
                q.whereGreaterThan("createdAt", lastMsgDate);
            q.whereEqualTo("receiver", blog.getId());
        }
        q.orderByDescending("createdAt");
        q.findInBackground(new FindCallback<ParseObject>() {

            @Override
            public void done(List<ParseObject> li, ParseException e)
            {
                if (li != null && li.size() > 0)
                {
                    for (int i = li.size() - 1; i >= 0; i--) {


                        ParseObject po = li.get(i);



                        Conversation c = new Conversation(po
                                .getString("message"), po.getCreatedAt(), po
                                .getString("sender"));


                        convList.add(c);
                        if (lastMsgDate == null
                                || lastMsgDate.before(c.getDate()))

                            lastMsgDate = c.getDate();
                        adp.notifyDataSetChanged();
                    }
                }

            }
        });

    }

    private class ChatAdapter extends BaseAdapter
    {

        public int getCount()
        {
            return convList.size();
        }

        public Conversation getItem(int arg0)
        {
            return convList.get(arg0);
        }
        @Override
        public long getItemId(int arg0)
        {
            return arg0;
        }
        @Override
        public View getView(int pos, View v, ViewGroup arg2) {
            Conversation c = getItem(pos);
            if (c.isSent())
                v = getLayoutInflater().inflate(R.layout.chat_item_sent, null);

            TextView lbl = (TextView) v.findViewById(R.id.lbl1);

            lbl.setText(DateUtils.getRelativeDateTimeString(Comments.this, c
                            .getDate().getTime(), DateUtils.SECOND_IN_MILLIS,
                    DateUtils.DAY_IN_MILLIS, 0));
            //	String mystring =(DateUtils.getRelativeDateTimeString(Chat.this, c
            //					.getDate().getTime();
            lbl = (TextView) v.findViewById(R.id.lbl2);

            lbl.setText(c.getMsg());


            return v;
        }

    }

    /* (non-Javadoc)
     * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == android.R.id.home)
        {
            finish();

        }

        return super.onOptionsItemSelected(item);
    }

}
