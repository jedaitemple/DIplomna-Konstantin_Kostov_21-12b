package kosio.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import kosio.myapplication.custom.CustomActivity;
import kosio.myapplication.Utilities.Utilily;

import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

public class Register extends CustomActivity
{


	private EditText user;
	private EditText password;
	private EditText email;

	/* (non-Javadoc)
	 * @see com.chatt.custom.CustomActivity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		user = (EditText) findViewById(R.id.user);
		password = (EditText) findViewById(R.id.pwd);
		email = (EditText) findViewById(R.id.email);

		final Button loginbutton = (Button)findViewById(R.id.btnReg);
		loginbutton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {
				String username = user.getText().toString();
				String password1 = password.getText().toString();
				String email1 = email.getText().toString();
				if (username.length() == 0 || password1.length() == 0 || email1.length() == 0)
				{
					Utilily.showDialog(Register.this, R.string.err_fields_empty);
					return;
				}

				final ParseUser pu = new ParseUser();
				pu.setEmail(email1);
				pu.setPassword(password1);
				pu.setUsername(username);
				pu.signUpInBackground(new SignUpCallback() {

					@Override
					public void done(ParseException e)
					{
						if (e == null)
						{
							Users.user = pu;
							startActivity(new Intent(Register.this, Main2Activity.class));
							finish();
						}
						else
						{
							Utilily.showDialog(
									Register.this,
									getString(R.string.err_singup) + " "
											+ e.getMessage());
							e.printStackTrace();
						}
					}
				});

			}
		});

	}

}
