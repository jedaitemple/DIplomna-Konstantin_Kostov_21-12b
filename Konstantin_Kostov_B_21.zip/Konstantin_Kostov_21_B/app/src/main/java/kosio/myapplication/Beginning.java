package kosio.myapplication;

import android.app.Application;
import com.parse.Parse;
import com.parse.ParseACL;

import com.parse.ParseUser;

import android.app.Application;
import com.parse.Parse;


public class Beginning extends Application
{

	/* (non-Javadoc)
	 * @see android.app.Application#onCreate()
	 */
	@Override
	public void onCreate()
	{
		super.onCreate();

		Parse.initialize(this, "wzFT5JIu1E7bPqPYnX1Z2uuZb0SivkYnYVeblgMO",
				"FfylMTFeHzJ4IOybGatUVCd3M6iQCwT6rTlhibop");
		ParseUser.enableAutomaticUser();
		ParseACL defaultACL = new ParseACL();

		// If you would like all objects to be private by default, remove this
		// line.
		defaultACL.setPublicReadAccess(true);

		Parse.setLogLevel(Parse.LOG_LEVEL_DEBUG);

		ParseUser.enableAutomaticUser();

		// If you would like all objects to be private by default, remove this
		// line.
		defaultACL.setPublicReadAccess(true);
		defaultACL.setPublicReadAccess(true);
		defaultACL.setPublicWriteAccess(true); //objects created are writable
		ParseACL.setDefaultACL(defaultACL, true);
		ParseACL.setDefaultACL(defaultACL, true);

	}
}
