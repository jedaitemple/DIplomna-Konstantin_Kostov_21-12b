package kosio.myapplication;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.parse.ParseObject;

import  kosio.myapplication.custom.CustomActivity;

import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.CountCallback;

/**
 * Created by Kosioplay on 1.2.2016 г..
 */
public class Statistics  extends CustomActivity {
   int a=0;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistics);
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Chat");
        query.whereEqualTo("sender", Users.user.getUsername());
        query.countInBackground(new CountCallback() {
            public void done(int count, ParseException e) {
                if (e == null) {

                    a = count;
                    final TextView txtValue = (TextView) findViewById(R.id.txtExample);
                    txtValue.setText(Integer.toString(count));
                } else {

                }
            }
        });
        ParseQuery<ParseObject> query1 = ParseQuery.getQuery("Chat");
        query1.whereEqualTo("receiver", Users.user.getUsername() );
        query1.countInBackground(new CountCallback() {
            public void done(int count, ParseException e) {
                if (e == null) {

                    a = count;
                    final TextView txtValue = (TextView) findViewById(R.id.txtExample1);
                    txtValue.setText(Integer.toString(count));
                } else {

                }
            }
        });


    }
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == android.R.id.home)
        {
            finish();

        }

        return super.onOptionsItemSelected(item);
    }
}
